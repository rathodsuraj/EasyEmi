export class Menu {
  public static menu: Array<any> = [
    {
      oe: [
        { path: "oedashboard",title: "Dashboard", icon: "pe-7s-graph", class: ""  },
        { path: "loandetails",title: "Loan Details", icon: "pe-7s-graph", class: ""  }
          ],
      re: [
        { path: "redashboard", title: "Dashboard", icon: "pe-7s-graph", class: "" }
          ],
      admin: [
        { path: "admindashboar", title: "Dashboard", icon: "pe-7s-graph", class: "" }
             ],
      bm: [
        { path: "bmdashboard", title: "Dashboard", icon: "pe-7s-graph", class: "" }
          ],
      ah: [
        { path: "ahdashboard", title: "Dashboard", icon: "pe-7s-graph", class: "" },
        { path: "loan-tranfer", title: "Loan Transfer", icon: "pe-7s-graph", class: "" },
        { path: "loan-receipt", title: "Loan Receipt", icon: "pe-7s-graph", class: "" },
        { path: "loan-ledger", title: "Loan Ledger", icon: "pe-7s-graph", class: "" },
        { path: "mis-report", title: "MIS Report", icon: "pe-7s-graph", class: "" }
          ],
      cm: [
        { path: "cmdashboard", title: "Dashboard", icon: "pe-7s-graph", class: "" }
          ]
        }
  ];
}
