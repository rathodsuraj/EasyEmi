import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmdashboard',
  templateUrl: './bmdashboard.component.html',
  styleUrls: ['./bmdashboard.component.scss']
})
export class BmdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
