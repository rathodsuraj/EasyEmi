import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loandetails',
  templateUrl: './loandetails.component.html',
  styleUrls: ['./loandetails.component.scss']
})
export class LoandetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
