export class LoanTransfer 
{
    id: number;
    date: string;
    name: string;
    loan_amt: number;
    acc_no: string;
    ifsc: string;
    transc_id: string;
  }