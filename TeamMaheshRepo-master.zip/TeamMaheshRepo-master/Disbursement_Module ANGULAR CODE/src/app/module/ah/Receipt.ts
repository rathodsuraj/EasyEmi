export class LoanReceipt
{
    id: number;
    recpt_no:number;
    date: string;
    name: string;
    address: string;
    loan_amt: number;
    emi_amt: number;
    total_emi: number;
    emi_start_date: string;
  }