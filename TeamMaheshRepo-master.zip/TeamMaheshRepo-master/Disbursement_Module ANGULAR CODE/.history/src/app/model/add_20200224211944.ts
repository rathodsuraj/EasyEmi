export class Add {
  area: string;
  city: string;
  state: String;
}
