import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmdashboard',
  templateUrl: './cmdashboard.component.html',
  styleUrls: ['./cmdashboard.component.scss']
})
export class CmdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
