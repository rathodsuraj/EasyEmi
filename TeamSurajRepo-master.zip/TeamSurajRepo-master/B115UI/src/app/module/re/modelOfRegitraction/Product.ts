export class Product{
    productId:number;
    productName:string;
    productSpecification:string;
    productPrice:number;
    productStatus:number;
}