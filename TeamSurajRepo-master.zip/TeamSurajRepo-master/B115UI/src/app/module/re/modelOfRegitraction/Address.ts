export class Address{
    customerAddressId :number;		
    
     residenceIs: string;
     residenceAddress: string;
	 area :string;
	 landmark :string;
	 city :string;
	 state :string;
	 country :string;
	 pincode:string;
	 residenceSince :string;
	

	  localResidenceIs :string;	
	  localResidenceAddress :string;
	  localArea :string;
	  localLandmark:string;
	  localCity :string;
	  localState :string;	
	  localPincode:string;
      localResidenceSince :string;
      
	   status :number;
	
}