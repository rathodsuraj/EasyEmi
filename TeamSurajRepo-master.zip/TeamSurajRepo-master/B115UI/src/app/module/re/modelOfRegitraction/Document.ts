export class Document{
  documentId:number;
  addressProof:any;
  idProof:any;
  photo:any;
  blankcheque:any;
  bankStatement:any;
  signature:any
  
}