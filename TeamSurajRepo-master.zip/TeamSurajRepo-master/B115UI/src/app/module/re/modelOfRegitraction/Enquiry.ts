export class Enquiry{
  public  enquiryId:number; 
  public name:string;
  public mobileNo:string;
  public email:string;
  public  productInterested:string;
  public state:string;
  public city:string;
}