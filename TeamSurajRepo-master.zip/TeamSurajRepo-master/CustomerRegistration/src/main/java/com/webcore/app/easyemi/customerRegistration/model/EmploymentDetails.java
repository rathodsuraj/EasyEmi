package com.webcore.app.easyemi.customerRegistration.model;

public class EmploymentDetails {
	
	private int employeeDetailsId;
	
	private String EmployeeType;
	
	private String IndustryType;
	
	private String NameOfCompanyOrBussiness;
	
	private String Desgignation;
	
	private String Address;
	

}
