package com.webcore.app.easyemi.customerRegistration.dto;

public class CustomerRegisterDto {

}
