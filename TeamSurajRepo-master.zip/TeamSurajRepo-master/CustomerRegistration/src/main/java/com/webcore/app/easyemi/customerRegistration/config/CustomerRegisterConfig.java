package com.webcore.app.easyemi.customerRegistration.config;

public class CustomerRegisterConfig {

}
