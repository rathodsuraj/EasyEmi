package com.webcore.app.easyemi.customerRegistration.model;

public class Enquiry {

}
