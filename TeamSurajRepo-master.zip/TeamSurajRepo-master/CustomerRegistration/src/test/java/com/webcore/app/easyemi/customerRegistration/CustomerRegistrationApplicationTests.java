package com.webcore.app.easyemi.customerRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
