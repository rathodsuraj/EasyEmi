## [1.1.0] - 2019-02-11
### Changes
- update to Angular 7
- update ng-bootstrap to version 4
- update all dependencies to latest versions 

## [1.0.0] - 2018-05-17
### Initial Release
