export class LoanCalculation{
    loanId: number;
    loanAmount: number;
    rateOfInterest: number;
    tenure: number;
    totalInterest: number;
    totalRepayment:number;
    loanInstallment:number;
}