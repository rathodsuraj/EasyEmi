export class emicardgeneration
{
  emiCardId:number;
  customerId:number
  currentMaxloanLimit:any;
  nextMaxLoanLimit:any;
  interestRate:any;
}