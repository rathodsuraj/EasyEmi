export class CustomerCibil{
    cibilId:number;
    cibilScore:number;
    customerId:number;
    cibilRemark:string;
    cibilScoreDateTime:string;
    status:string;

}