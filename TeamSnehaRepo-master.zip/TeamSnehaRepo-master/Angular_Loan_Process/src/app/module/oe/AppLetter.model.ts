export class AppLetter{
    approvalLetterId:number;
    customerId :number;
    productId :number;
    loanAmount:any;
    rateOfIntrest:any;
        	
        }