import { LoanCalculation } from './loanCalculation';

export class LoanDetails{

    loanDetailId: number;
    product: string;
    loanAccountNo: number;
    customerId:number;
    loanCalculation:LoanCalculation;
   
}