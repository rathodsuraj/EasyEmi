
export class DocumentVerificationModel
{
    documentVerificationId:number;
	firstLevelVerifyByOE:string;
	firstLevelVerifyBySE:string;
	secondLevelVerifyByThirdParty:string;
	approvedByOE:string;
	approvedBySE:string;
	pendingDocuments:string;
	status:string;
	remark:string;
    customerId:number;
    //customerdetails:CustomerDetailsModel[];
    
            
  
  
	
}
