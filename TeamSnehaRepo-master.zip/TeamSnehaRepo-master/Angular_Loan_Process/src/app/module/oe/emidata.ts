export class emidata
{
  emiDetailsId:number;
  customerId:number;
  productId:number;
  customerName:String;
  monthlyEmiAmount:any;
  installment:number;    
}