export class CustomerDetails{

    customerId:number;
    customerFirstName:string;
    customerMiddleName:string;
    customerLastName:string;
    customerDataOfBirth:string;
    customerGender:string;
    customerMaritailStatus:string;
    customerMobileNumber:string;
    customerAddress:string;
    customerEducation:string;
    customerAppliedLoadAmount:string;
    status:null;
}