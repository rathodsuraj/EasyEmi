export class Menu {
  public static menu: Array<any> = [
    {
      oe: [
        { path: "oedashboard",title: "Dashboard", icon: "pe-7s-graph", class: ""  },
        { path: "loandetails",title: "Loan Details", icon: "pe-7s-graph", class: ""  },
        {path: "customercibil", title:"customer Cibil", icon: "pe-7s-graph", class: ""},
        { path: "emidetails",title: "EMI DETAILS", icon: "pe-7s-graph", class: ""  },
        { path: "documentverification",title: "Document Verification", icon: "pe-7s-graph", class: ""  },
        { path: "appletterregistration",title: "Approval Letter", icon: "pe-7s-graph", class: ""  },         { path: "loanstatement",title: "Loan Statement", icon: "pe-7s-graph", class: ""  },
         { path: "loanstatementdetails",title: "Loan Statement Details", icon: "pe-7s-graph", class: ""  },
         { path: "customertdetails",title: "Customer Details", icon: "pe-7s-graph", class: ""  },

      ],
      re: [
        {
          path: "redashboard", title: "Dashboard", icon: "pe-7s-graph", class: "" }
      ],admin: [
        {
          path: "admindashboar", title: "Dashboard", icon: "pe-7s-graph", class: "" }
      ],
      bm: [
        {
          path: "bmdashboard",
          title: "Dashboard",
          icon: "pe-7s-graph",
          class: ""
        }
      ],
      ah: [
        {
          path: "ahdashboard",
          title: "Dashboard",
          icon: "pe-7s-graph",
          class: ""
        }
      ],
      cm: [
        {
          path: "cmdashboard",
          title: "Dashboard",
          icon: "pe-7s-graph",
          class: ""
        }
      ]
    }
  ];
}
